import sys
import os

from pyjs.runners import RunnerManager

#TODO: very ugly to self-import and setattr(self) ... remove ASAP!
import pyjd


pyjdversion = '0.8.1~+alpha1'
pyjdinitpth = 'c:\\pyjs'


_manager = RunnerManager()
_manager.set_conf()
for key, value in _manager._conf.iteritems():
    setattr(pyjd, key, value)
_manager.set_runner()


#TODO: perm delete ASAP unless someone claims use; disable for now
#sys.path = [os.path.join(pyjdinitpth, 'pygtkweb', 'library')] + sys.path
sys.path += [os.path.join(pyjdinitpth, 'library')]


add_setup_callback = _manager.add_setup_listener
setup = _manager.setup
run = _manager.run
