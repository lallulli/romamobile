is_desktop = False

def setup(application, appdir=None, width=800, height=600):
    pass

def run(one_event=False, block=True):
    pass
