# PyJS does not support weak references, so WeakSet is eq. to set

WeakSet = set
