__CalendarProvider.prototype.__class__ = "CalendarProvider";
function CalendarProvider() {
    return new __CalendarProvider();
}
function __CalendarProvider() {
}
__CalendarProvider.prototype.pushResults = function(acceptor, startRow, people) {

        var __person = people.__iter__();
        try {
            while (true) {
                var person = __person.next();
                
        

            }
        } catch (e) {
            if (e != StopIteration) {
                throw e;
            }
        }
        
};
