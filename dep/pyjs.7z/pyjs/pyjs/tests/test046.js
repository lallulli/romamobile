function test() {
    var bar = pyjslib_slice(foo, 1, 5);
}


