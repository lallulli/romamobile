class DynaTableWidge:
    def setStatusText(self, text):
        self.navbar.status.setText(text)
