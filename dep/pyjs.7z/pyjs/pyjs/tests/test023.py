class CalendarProvider:

    def pushResults(self, acceptor, startRow, people):
        for person in people:
            pass
