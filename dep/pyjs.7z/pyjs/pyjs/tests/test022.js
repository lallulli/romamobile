__DynaTable.prototype.__class__ = "DynaTable";
function DynaTable() {
    return new __DynaTable();
}
function __DynaTable() {
}
__DynaTable.prototype.onModuleLoad = function() {
    var slot = __ui_RootPanel.get.call("calendar");
};
