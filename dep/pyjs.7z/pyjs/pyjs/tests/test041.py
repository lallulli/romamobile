def test():
    if foo in bar:
        do_something()
    if foo not in bar:
        do_something_else()
    if foo or bar:
        good()
    if foo and bar:
        bad()
