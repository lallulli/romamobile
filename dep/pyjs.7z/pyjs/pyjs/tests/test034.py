JS("""
var x = 1;
""")

def test():
    JS("""
    var x = 2;
    """)
