class Foo:
    BAR = 1
    BAZ = 2

def test():
    return Foo.BAR