def test(x):
    return int(x)
