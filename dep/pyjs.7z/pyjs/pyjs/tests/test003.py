class UIObject:
    pass


class Widget(UIObject):

    def setParent(self, parent):
        self.parent = parent
