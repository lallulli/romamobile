from baz import Baz

class Foo:
    pass

def test():
    foo = Foo()
    bar = Foo
    Baz.doSomething()