function test() {
    var foo = new pyjslib_Dict([]);
    foo.__setitem__("five", 5);
    foo.__delitem__("five");
}


