from foo import Foo

class Bar(Foo):
    pass
