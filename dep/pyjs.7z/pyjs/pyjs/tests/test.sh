#!/bin/sh
echo test001; ../pyjs.py test001.py ui | diff - test001.js
echo test002; ../pyjs.py test002.py ui | diff - test002.js
echo test003; ../pyjs.py test003.py ui | diff - test003.js
echo test004; ../pyjs.py test004.py ui | diff - test004.js
echo test005; ../pyjs.py test005.py ui | diff - test005.js
echo test006; ../pyjs.py test006.py ui | diff - test006.js
echo test007; ../pyjs.py test007.py ui | diff - test007.js
echo test008; ../pyjs.py test008.py ui | diff - test008.js
echo test009; ../pyjs.py test009.py ui | diff - test009.js
echo test010; ../pyjs.py test010.py    | diff - test010.js
echo test011; ../pyjs.py test011.py    | diff - test011.js
echo test012; ../pyjs.py test012.py    | diff - test012.js
echo test013; ../pyjs.py test013.py ui | diff - test013.js
echo test014; ../pyjs.py test014.py    | diff - test014.js
echo test015; ../pyjs.py test015.py    | diff - test015.js
echo test016; ../pyjs.py test016.py    | diff - test016.js
echo test017; ../pyjs.py test017.py    | diff - test017.js
echo test018; ../pyjs.py test018.py    | diff - test018.js
echo test019; ../pyjs.py test019.py    | diff - test019.js
echo test020; ../pyjs.py test020.py    | diff - test020.js
echo test021; ../pyjs.py test021.py    | diff - test021.js
echo test022; ../pyjs.py test022.py    | diff - test022.js
echo test023; ../pyjs.py test023.py    | diff - test023.js
echo test024; ../pyjs.py test024.py    | diff - test024.js
echo test025; ../pyjs.py test025.py    | diff - test025.js
echo test026; ../pyjs.py test026.py    | diff - test026.js
echo test027; ../pyjs.py test027.py    | diff - test027.js
echo test028; ../pyjs.py test028.py    | diff - test028.js
echo test029; ../pyjs.py test029.py    | diff - test029.js
echo test030; ../pyjs.py test030.py    | diff - test030.js
echo test031; ../pyjs.py test031.py    | diff - test031.js
echo test032; ../pyjs.py test032.py    | diff - test032.js
echo test033; ../pyjs.py test033.py    | diff - test033.js
echo test034; ../pyjs.py test034.py    | diff - test034.js
echo test035; ../pyjs.py test035.py    | diff - test035.js
echo test036; ../pyjs.py test036.py    | diff - test036.js
echo test037; ../pyjs.py test037.py    | diff - test037.js
echo test038; ../pyjs.py test038.py    | diff - test038.js
echo test039; ../pyjs.py test039.py    | diff - test039.js
echo test040; ../pyjs.py test040.py    | diff - test040.js
echo test041; ../pyjs.py test041.py    | diff - test041.js
echo test042; ../pyjs.py test042.py    | diff - test042.js
echo test043; ../pyjs.py test043.py    | diff - test043.js
echo test044; ../pyjs.py test044.py    | diff - test044.js
echo test045; ../pyjs.py test045.py    | diff - test045.js
echo test046; ../pyjs.py test046.py    | diff - test046.js
echo test047; ../pyjs.py test047.py    | diff - test047.js
