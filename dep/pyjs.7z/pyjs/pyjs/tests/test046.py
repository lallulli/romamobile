def test():
    bar = foo[1:5]
