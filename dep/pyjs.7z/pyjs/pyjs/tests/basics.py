def test(name, result):
    if not result:
        print name, 'failed'
