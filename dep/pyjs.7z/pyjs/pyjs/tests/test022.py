import ui

class DynaTable:

    def onModuleLoad(self):
        slot = ui.RootPanel.get("calendar")