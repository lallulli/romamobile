__RowDataAcceptorImpl.prototype.__class__ = "RowDataAcceptorImpl";
function RowDataAcceptorImpl() {
    return new __RowDataAcceptorImpl();
}
function __RowDataAcceptorImpl() {
}
__RowDataAcceptorImpl.prototype.accept = function(startRow, data) {
    var srcRowIndex = 0;
    var srcRowCount = 5;
    var destRowIndex = 1;
    while ((srcRowIndex < srcRowCount)) {
    srcRowIndex += 1;
    destRowIndex += 1;
    }
};
