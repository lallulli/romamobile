
var x = 1;

function test() {

    var x = 2;
    
}


