def test():
    x = -y
    x = y + z
    x = y - z
    x = y * z
    x = y / z
    x = y % z
    x = ~y
    x = y & z
    x = y | z
