class DayFilterWidget:
    def setAllCheckBoxes(self, checked):
        for widget in self.outer.getWidgets():
            pass
