function test() {
    var x = -y;
    var x =  ( y + z ) ;
    var x =  ( y - z ) ;
    var x =  ( y * z ) ;
    var x =  ( y / z ) ;
    var x = y % z;
    var x = ~y;
    var x = (y & z);
    var x = (y | z);
}


