class SchoolCalendarWidget:
    def getDayIncluded(self, day):
        return self.daysFilter[day]
