def test():
    foo = {}
    foo["five"] = 5
    del foo["five"]
