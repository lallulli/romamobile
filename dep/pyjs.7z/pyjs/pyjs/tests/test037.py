class Test:
    def test(self, foo=5):
        pass
