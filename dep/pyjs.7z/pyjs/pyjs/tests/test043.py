def test():
    for i, j in pairs:
        pass
