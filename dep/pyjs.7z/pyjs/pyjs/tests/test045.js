function test() {
    var x = new pyjslib_Dict([[1, 1], [2, 2]]);
}


