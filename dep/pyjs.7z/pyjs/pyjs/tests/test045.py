# dictionary tests

def test():
    x = {1:1, 2:2}
