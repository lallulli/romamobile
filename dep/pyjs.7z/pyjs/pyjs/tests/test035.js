__Foo.prototype.__class__ = "Foo";
function Foo() {
    return new __Foo();
}
function __Foo() {
}
function test() {
    var foo = Foo();
    var bar = Foo;
    __baz_Baz.prototype.doSomething.call();
}


