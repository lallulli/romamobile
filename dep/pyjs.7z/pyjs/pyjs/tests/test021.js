__DayFilterWidget.prototype.__class__ = "DayFilterWidget";
function DayFilterWidget() {
    return new __DayFilterWidget();
}
function __DayFilterWidget() {
}
__DayFilterWidget.prototype.setAllCheckBoxes = function(checked) {

        var __widget = this.outer.getWidgets().__iter__();
        try {
            while (true) {
                var widget = __widget.next();
                
        

            }
        } catch (e) {
            if (e != StopIteration) {
                throw e;
            }
        }
        
};
