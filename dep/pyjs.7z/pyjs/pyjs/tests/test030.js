__DynaTableWidge.prototype.__class__ = "DynaTableWidge";
function DynaTableWidge() {
    return new __DynaTableWidge();
}
function __DynaTableWidge() {
}
__DynaTableWidge.prototype.setStatusText = function(text) {
    this.navbar.status.setText(text);
};
