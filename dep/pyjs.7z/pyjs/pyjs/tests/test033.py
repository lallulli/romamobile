from foo import bar

def test():
    a = y
    b = x.y
    c = self.y
    d = bar.y
    e = Baz.y
    f = x.y.z
    g = x[0].y
    h = x().y