from __pyjamas__ import get_main_frame, JS

def create_xml_doc(text):
    return None

