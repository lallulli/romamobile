BUTT = "flat"

DESTINATION_OVER = "afterBegin"

SOURCE_OVER = "beforeEnd"

