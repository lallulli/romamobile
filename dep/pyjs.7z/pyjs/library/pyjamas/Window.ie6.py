
def getClientHeight():
    return doc().body.clientHeight

def getClientWidth():
    return doc().body.clientWidth

