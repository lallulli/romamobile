def init():
    # PyV8 lacks proper DOM support
    return False