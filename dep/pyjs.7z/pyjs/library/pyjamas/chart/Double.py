NaN = 1.7976931348623157e+308

# XXX total guesses!
MAX_VALUE = 1e+100
MIN_VALUE = -1e+100

import math

def isNaN(num):
    """ returns True if number is "not a number"
    """
    return num == NaN
