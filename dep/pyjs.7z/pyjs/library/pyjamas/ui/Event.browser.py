def init():
    eventbits[0x040000] = ("mousescroll", ["mousewheel"])
