def setStyleElementText(el, text):
    el.styleSheet.cssText = text

